
import tkinter as tk
from .view import View
from .model import Model

from .controller import Controller


def main(file):
    root = tk.Tk()

    model = Model()
    model.open(file)

    view = View(root)

    controller = Controller(model, view)
    controller.update_view()
    
    root.mainloop()

    
 