# controller.py
class Controller:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.view.set_button_command(self.update_model)

    def update_model(self):
        pass
        # new_data = self.view.get_entry_text()
        # self.model.set_data(new_data)
        # self.update_view()

    def update_view(self):
        data = self.model.get_data()
        self.view.set_label_text(data)
