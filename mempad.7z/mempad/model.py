
import markdown
import os

class Model:
    
  def __init(self):
    self.__pages = []
    self.__num_pages = 0
    self.__filename = ''
   
  def open(self, filename):
    "read lst mempad file"   
    self.__dir = os.path.dirname(os.path.realpath(__file__))
    print(self.__dir )
    str = Model.__readFile(filename)
  
    if not str.startswith('MeMpAd.'):
      import sys
      sys.exit(filename + ' is NOT Mempad file.')
  
    index = str.index('\1')
    str = str[index:]
    arr = str.split('\0')
    titles = []
    pages = []
    index = 0
    enum = enumerate(arr)
    for i, item in enum:
      if i & 1 == 0 and item : # titles
        level = ord(item[0])
        title = item[1:]
      else:
        pages.append(( len(pages), level, title, item))
        index += 1 
      
    self.__pages = pages
    self.__num_pages = len(pages)
    self.__filename = filename

  def toHtml(self,filename = None):
    "write to html"  
    
    links = ''
    pages = ''

    if not filename :
      filename = f'{self.__filename[0:-4]}.html'

    for id, level, title, page in self.__pages :
      dots = ' ' * (level - 1)
      links += f'<a href="javascript:show({id})">{dots}{title}</a>\n'
     
      if title[:-4] != '.ini' :
        page = markdown.markdown(page)
      pages += f'<div id="id{id}">{page}</div>\n'

    html = Model.__readFile(self.__dir + '/assets/template.html')
    css = Model.__readFile(self.__dir + '/assets/mempad.css')
    js = Model.__readFile(self.__dir + '/assets/mempad.js')
    html = html.format(links=links, pages = pages, css = css, js = js)

    
    f = open(filename, 'w', encoding='utf-8')
    f.write(html)
    f.close()
    
  def get_data(self):
      return str(self.__num_pages) + ' pages'
  @property
  def num_pages(self):
      return self.__num_pages

  @staticmethod
  def __readFile(filename) :
    "read file"  
    f = open(filename, 'r', encoding='utf-8')
    str = f.read()
    f.close()  
    return str